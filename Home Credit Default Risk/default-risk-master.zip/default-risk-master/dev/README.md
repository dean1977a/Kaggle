dev
=======
Folder for exploratory analysis and development.  If you do an analysis or write some code that leads to useful information/processing but is not yet part of the main processing/training pipeline, it should show up here.  Most often, these will be Jupyter notebooks (`.ipynb` files).

ray
=======

pip users:

```pip install -r requirements.txt```

Anaconda users:

```conda env create -f default-risk.yml```

python dev/mnist-ray.py
