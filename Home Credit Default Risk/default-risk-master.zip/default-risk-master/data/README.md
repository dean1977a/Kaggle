data
=======
A placeholder for the csvs.  They're too big for GitHub, so they're in the .gitignore, but in order for the other scripts to work, you need to download the compressed tables from kaggle, unzip them, and move all the tables into this folder.