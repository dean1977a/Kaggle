from setuptools import setup, find_packages
setup(
    name="default-risk",
    version="0.1lildev",
    packages=find_packages(),
)
